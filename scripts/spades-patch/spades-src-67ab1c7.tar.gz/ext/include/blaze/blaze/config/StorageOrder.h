//=================================================================================================
/*!
//  \file blaze/config/StorageOrder.h
//  \brief Configuration of the default storage order for all matrices of the Blaze library
//
//  Copyright (C) 2012-2020 Klaus Iglberger - All Rights Reserved
//
//  This file is part of the Blaze library. You can redistribute it and/or modify it under
//  the terms of the New (Revised) BSD License. Redistribution and use in source and binary
//  forms, with or without modification, are permitted provided that the following conditions
//  are met:
//
//  1. Redistributions of source code must retain the above copyright notice, this list of
//     conditions and the following disclaimer.
//  2. Redistributions in binary form must reproduce the above copyright notice, this list
//     of conditions and the following disclaimer in the documentation and/or other materials
//     provided with the distribution.
//  3. Neither the names of the Blaze development group nor the names of its contributors
//     may be used to endorse or promote products derived from this software without specific
//     prior written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY
//  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
//  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
//  SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
//  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
//  TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
//  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
//  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
//  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
//  DAMAGE.
*/
//=================================================================================================


//*************************************************************************************************
/*!\brief The default storage order for all matrices of the Blaze library.
// \ingroup config
//
// This value specifies the default storage order for all matrices of the Blaze library.
// In case no explicit storage order is specified with the according matrix type, this
// setting is used.

   \code
   // Explicit specification of the storage order => row-major matrix
   StaticMatrix<double,3UL,3UL,rowMajor> A;

   // No explicit specification of the storage order => use of the default storage order
   StaticMatrix<double,3UL,3UL> B;
   \endcode

// Valid settings for the BLAZE_DEFAULT_STORAGE_ORDER are blaze::rowMajor and blaze::columnMajor.
//
// \note It is possible to specify the default storage order via command line or by defining this
// symbol manually before including any Blaze header file:

   \code
   g++ ... -DBLAZE_DEFAULT_STORAGE_ORDER=blaze::rowMajor ...
   \endcode

   \code
   #define BLAZE_DEFAULT_STORAGE_ORDER blaze::rowMajor
   #include <blaze/Blaze.h>
   \endcode
*/
#ifndef BLAZE_DEFAULT_STORAGE_ORDER
#define BLAZE_DEFAULT_STORAGE_ORDER blaze::rowMajor
#endif
//*************************************************************************************************
